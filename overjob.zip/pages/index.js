import axios from 'axios';

import styles from '../styles/pages/Home.module.css'
import Header from '../src/components/Header';
import Filters from '../src/components/Filters';
import Card from '../src/components/Card';
import { useState } from 'react';

export default function Home({ jobs }) {
  const [filter, setFilter] = useState({
    Estado: [],
    Modalidade: [],
    Nivel: [],
    Regime: [],
    Categoria: []
  });

  const [jobList, setJobList] = useState(jobs);

  const [activeFilters, setActiveFilters] = useState({});
  
  return (
    <div className={styles.structure}>
      <Header /> 
      <div className={styles.cardContainer}>
        <Filters />
        <Card />
      </div>
    </div>
  )
}

export async function getStaticProps() {

  const { data: { error, jobs = []} } = await axios.get('http://localhost:3000/api/jobs')

  return {
    props: {
      jobs: jobs
    },
    revalidate: 5000
  }
}
