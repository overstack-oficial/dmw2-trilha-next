import styles from '../../../styles/components/Filters.module.css';

function Filters() {
  return (
    <div className={styles.filters}>
      <h4 className={styles.title}>Categotia</h4>
      <ul className={styles.filter_list}>
        <li>
          <input type="checkbox" name="teste" />
          <label>SP</label>
        </li>
      </ul>
    </div>
  )
}

export default Filters;