(function() {
var exports = {};
exports.id = "pages/api/jobs";
exports.ids = ["pages/api/jobs"];
exports.modules = {

/***/ "./pages/api/jobs.js":
/*!***************************!*\
  !*** ./pages/api/jobs.js ***!
  \***************************/
/***/ (function(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": function() { return /* binding */ handler; }
/* harmony export */ });
/* harmony import */ var _src_docs_jobs_json__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../src/docs/jobs.json */ "./src/docs/jobs.json");
// Next.js API route support: https://nextjs.org/docs/api-routes/introduction

function handler(req, res) {
  const {
    id
  } = req.query;

  if (req.query.secret === 'over') {
    if (req.method === 'GET') {
      if (id) {
        const [job = {}] = _src_docs_jobs_json__WEBPACK_IMPORTED_MODULE_0__.filter(job => job.id == id);
        res.status(200).json({
          error: false,
          jobs: job
        });
      } else {
        res.status(200).json({
          error: false,
          jobs: _src_docs_jobs_json__WEBPACK_IMPORTED_MODULE_0__
        });
      }
    } else {
      res.status(400).json({
        error: true,
        message: "Método não suportado"
      });
    }
  } else {
    res.status(400).json({
      error: true,
      message: "Secret inválida"
    });
  }
}

/***/ }),

/***/ "./src/docs/jobs.json":
/*!****************************!*\
  !*** ./src/docs/jobs.json ***!
  \****************************/
/***/ (function(module) {

"use strict";
module.exports = JSON.parse('[{"id":1,"title":"Vaga Para Desenvolvedor Sênior","description":"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \'de Finibus Bonorum et Malorum\' (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \'Lorem ipsum dolor sit amet..\', comes from a line in section 1.10.32.\\nThe standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \'de Finibus Bonorum et Malorum\' by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.","category":"Back-end","type":"CLT","level":"Senior","model":"Presencial","state":"SP","city":"São Paulo","day":"30 de Maio","min_salary":1000,"max_salary":3000,"enterprise":"Overstack","enterprise_description":"It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."},{"id":2,"title":"Vaga Para Desenvolvedor Pleno","description":"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \'de Finibus Bonorum et Malorum\' (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \'Lorem ipsum dolor sit amet..\', comes from a line in section 1.10.32.\\nThe standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \'de Finibus Bonorum et Malorum\' by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.","category":"Front-end","type":"PJ","level":"Pleno","model":"Presencial","state":"SP","city":"São Paulo","day":"20 de Maio","min_salary":2000,"max_salary":5000,"enterprise":"Overstack","enterprise_description":"It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."},{"id":3,"title":"Vaga Para Desenvolvedor Junior","description":"Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \'de Finibus Bonorum et Malorum\' (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \'Lorem ipsum dolor sit amet..\', comes from a line in section 1.10.32.\\nThe standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \'de Finibus Bonorum et Malorum\' by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.","category":"Back-end","type":"CLT","level":"Junior","model":"Remoto","state":"AL","city":"Maceió","day":"10 de Maio","min_salary":1000,"max_salary":2000,"enterprise":"Overstack","enterprise_description":"It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like)."}]');

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = function(moduleId) { return __webpack_require__(__webpack_require__.s = moduleId); }
var __webpack_exports__ = (__webpack_exec__("./pages/api/jobs.js"));
module.exports = __webpack_exports__;

})();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9vdmVyam9iLy4vcGFnZXMvYXBpL2pvYnMuanMiXSwibmFtZXMiOlsiaGFuZGxlciIsInJlcSIsInJlcyIsImlkIiwicXVlcnkiLCJzZWNyZXQiLCJtZXRob2QiLCJqb2IiLCJqb2JzIiwic3RhdHVzIiwianNvbiIsImVycm9yIiwibWVzc2FnZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUVlLFNBQVNBLE9BQVQsQ0FBaUJDLEdBQWpCLEVBQXNCQyxHQUF0QixFQUEyQjtBQUN4QyxRQUFNO0FBQUVDO0FBQUYsTUFBU0YsR0FBRyxDQUFDRyxLQUFuQjs7QUFDQSxNQUFHSCxHQUFHLENBQUNHLEtBQUosQ0FBVUMsTUFBVixLQUFxQixNQUF4QixFQUFnQztBQUM5QixRQUFHSixHQUFHLENBQUNLLE1BQUosS0FBZSxLQUFsQixFQUF5QjtBQUN2QixVQUFHSCxFQUFILEVBQU87QUFDTCxjQUFNLENBQUNJLEdBQUcsR0FBRyxFQUFQLElBQWFDLHVEQUFBLENBQVlELEdBQUcsSUFBSUEsR0FBRyxDQUFDSixFQUFKLElBQVVBLEVBQTdCLENBQW5CO0FBQ0FELFdBQUcsQ0FBQ08sTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ25CQyxlQUFLLEVBQUUsS0FEWTtBQUVuQkgsY0FBSSxFQUFFRDtBQUZhLFNBQXJCO0FBSUQsT0FORCxNQU1PO0FBQ0xMLFdBQUcsQ0FBQ08sTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ25CQyxlQUFLLEVBQUUsS0FEWTtBQUVuQkgsY0FBSUE7QUFGZSxTQUFyQjtBQUlEO0FBQ0YsS0FiRCxNQWFPO0FBQ0xOLFNBQUcsQ0FBQ08sTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ25CQyxhQUFLLEVBQUUsSUFEWTtBQUVuQkMsZUFBTyxFQUFFO0FBRlUsT0FBckI7QUFJRDtBQUNGLEdBcEJELE1Bb0JPO0FBQ0xWLE9BQUcsQ0FBQ08sTUFBSixDQUFXLEdBQVgsRUFBZ0JDLElBQWhCLENBQXFCO0FBQ25CQyxXQUFLLEVBQUUsSUFEWTtBQUVuQkMsYUFBTyxFQUFFO0FBRlUsS0FBckI7QUFJRDtBQUdGLEMiLCJmaWxlIjoicGFnZXMvYXBpL2pvYnMuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBOZXh0LmpzIEFQSSByb3V0ZSBzdXBwb3J0OiBodHRwczovL25leHRqcy5vcmcvZG9jcy9hcGktcm91dGVzL2ludHJvZHVjdGlvblxuaW1wb3J0IGpvYnMgZnJvbSAnLi4vLi4vc3JjL2RvY3Mvam9icy5qc29uJ1xuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XG4gIGNvbnN0IHsgaWQgfSA9IHJlcS5xdWVyeTtcbiAgaWYocmVxLnF1ZXJ5LnNlY3JldCA9PT0gJ292ZXInKSB7XG4gICAgaWYocmVxLm1ldGhvZCA9PT0gJ0dFVCcpIHtcbiAgICAgIGlmKGlkKSB7XG4gICAgICAgIGNvbnN0IFtqb2IgPSB7fV0gPSBqb2JzLmZpbHRlcihqb2IgPT4gam9iLmlkID09IGlkKVxuICAgICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7XG4gICAgICAgICAgZXJyb3I6IGZhbHNlLFxuICAgICAgICAgIGpvYnM6IGpvYlxuICAgICAgICB9KVxuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oe1xuICAgICAgICAgIGVycm9yOiBmYWxzZSxcbiAgICAgICAgICBqb2JzXG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIHJlcy5zdGF0dXMoNDAwKS5qc29uKHtcbiAgICAgICAgZXJyb3I6IHRydWUsXG4gICAgICAgIG1lc3NhZ2U6IFwiTcOpdG9kbyBuw6NvIHN1cG9ydGFkb1wiXG4gICAgICB9KVxuICAgIH1cbiAgfSBlbHNlIHtcbiAgICByZXMuc3RhdHVzKDQwMCkuanNvbih7XG4gICAgICBlcnJvcjogdHJ1ZSxcbiAgICAgIG1lc3NhZ2U6IFwiU2VjcmV0IGludsOhbGlkYVwiXG4gICAgfSlcbiAgfVxuICBcbiAgXG59XG4iXSwic291cmNlUm9vdCI6IiJ9